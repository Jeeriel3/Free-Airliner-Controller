using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlaneController : MonoBehaviour
{
    [Header("References:")]
    public Rigidbody Main;
    public GameObject brakesText;
    public GameObject SpoilerText;
    public Transform EngineLeft;
    public Transform EngineRight;
    public Transform Cross;
    public AudioSource EngineSound;
    public GameObject GearLeftNormal;
    public GameObject GearRightNormal;
    public GameObject GearLeftTilted;
    public GameObject GearRightTilted;
    public GameObject CursorObj;
    public Transform EngineLeftProps;
    public Transform EngineRightProps;
    public GameObject StallText;
    public GameObject TerrainWarning;
    public Text SpeedText;
    public Text AltitudeText;
    public Slider slider1;
    public Slider slider2;
    public Animator animator;

    [Space(20)]

    [Header("Variables:")]
    public float Throttle;
    public float ThrottleIncreasement;
    public float EnginePower;
    public float ThrottleMultiplyer;
    public float rotation;
    public float rotationPower;
    public float pitchPower;
    public float pitch;
    public float speed;
    public float Altitude;
    public float LiftPoint;
    public float BrakeForce;
    public float SpoilerForce;
    public float PushbackForce;
    public float responseifness;
    private float rollMouse;
    private float pitchMouse;
    private float yaw;

    private float responseModifier
    {
        get
        {
            return (Main.mass / 10f * responseifness);
        }
    }
    [Space(20)]

    [Header("Booleans:")]
    public bool stall;
    public bool brakes;
    public bool spoilers;
    public bool GearUp;
    public bool pushback;
    public bool Grounded;
    public bool MouseControls;
    public bool EngineFailure;
    private bool ActivateStall;
    private bool Paused;

    // Update is called once per frame
    void Update()
    {
        yaw = Input.GetAxis("Yaw");
        
        if(speed < 635 && !EngineFailure)
        {
            Main.AddForce(transform.forward * EnginePower * Throttle);

            //Main.AddForceAtPosition(transform.forward * EnginePower * Throttle * ThrottleMultiplyer, EngineLeft.position);
            //Main.AddForceAtPosition(transform.forward * EnginePower * Throttle * ThrottleMultiplyer, EngineRight.position);
        }


        if(ActivateStall)
            Main.AddForce(-transform.forward * EnginePower * SpoilerForce);

        speed = Main.velocity.magnitude * 3.6f;
        EngineSound.pitch = Throttle / 80;

        if(speed > LiftPoint / 2)
        Main.AddTorque(transform.up * yaw * responseModifier / 2);

        SpeedText.text = Mathf.Round(speed).ToString() + " Km/H";
        AltitudeText.text = Mathf.Round(Altitude).ToString() + " M";

        slider1.value = Throttle;
        slider2.value = Throttle;

        GetInput();
        CheckState();
        GetSpoilerState();
        UpdateGear();
        RotateEngineProps();
        ChanceGear();
        HandlePushback();
        SetCursorState();

        //BRAKES/SPOILERS//
        if(brakes && speed > -20)
        {
            Main.AddForce(-transform.forward * EnginePower * BrakeForce);
            brakesText.SetActive(true);
        }
        else
            brakesText.SetActive(false);

        if(spoilers && speed > 0)
        {
            Main.AddForce(-transform.forward * EnginePower * SpoilerForce);
            SpoilerText.SetActive(true);
        }
        else
            SpoilerText.SetActive(false);


        //CONTROLS//
        if(MouseControls)
        {
            if(speed > LiftPoint / 2)
            {
                pitchMouse = Input.GetAxis("Mouse Y");
                rollMouse = Input.GetAxis("Mouse X");

                Main.AddTorque(-transform.right * pitchMouse * responseModifier);
                Main.AddTorque(-transform.forward * rollMouse * responseModifier); 
            }
            Cross.position = new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0);
        }
        else
        {
            if(speed > LiftPoint / 2)
            {
                FixRotation();
                FixPitch();
                Main.AddTorque(transform.forward * rotationPower * rotation);
                Main.AddTorque(transform.right * pitchPower * pitch);
            }
        }

        if(pushback && Grounded)
        {
            Main.AddForce(-transform.forward * EnginePower * PushbackForce);
        }
    }

    public void Start()
    {
        if(MouseControls)
        CursorObj.SetActive(true);
        else
        CursorObj.SetActive(false);
    }

    public void GetInput()
    {
        if(Input.GetKey(KeyCode.Space))
        {
            if(Throttle < 100)
            Throttle += ThrottleIncreasement;
        }

        if(Input.GetKey(KeyCode.LeftShift))
        {
            if(Throttle > 0)
            Throttle -= ThrottleIncreasement;
        }

        if(Input.GetKey(KeyCode.A))
        {
            if(rotation < 100)
            rotation += 1;
        }

        if(Input.GetKey(KeyCode.D))
        {
            if(rotation > -100)
            rotation -= 1;
        }

        if(Input.GetKey(KeyCode.S))
        {
            if(pitch < 100)
            pitch += 1;
        }

        if(Input.GetKey(KeyCode.W))
        {
            if(pitch > -100)
            pitch -= 1;
        }

        if(Input.GetKeyDown(KeyCode.Z))
        {
            if(MouseControls)
            {
                MouseControls = false;
                CursorObj.SetActive(false);
            }
            else
            {
                MouseControls = true;
                CursorObj.SetActive(true);
            }
        }
    }

    public void FixRotation()
    {
        if(!Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.A))
        {
            if(rotation > 0)
            rotation -= 1;

            if(rotation < 0)
            rotation += 1;
        }
    }

    public void FixPitch()
    {
        if(!Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.S))
        {
            if(pitch > 0)
            pitch -= 1;

            if(pitch < 0)
            pitch += 1;
        }
    }

    public void CheckState()
    {
        Altitude = transform.position.y;

        if(speed < LiftPoint)
            Main.useGravity = true;
        else
            Main.useGravity = false;


        if(!Grounded && speed < 150)
        {
            stall = true;
            StallText.SetActive(true);
        }
        else
        {
            stall = false;
            StallText.SetActive(false);
        }


        if(Input.GetKey(KeyCode.B) && Grounded)
            if(brakes)
                brakes = false;
            else
                brakes = true;
        
        if(Throttle < 10 && !Grounded)
            ActivateStall = true;
        else
            ActivateStall = false;


        if(speed < 20 && Grounded)
            EnginePower = 50000;
        else
            EnginePower = 500;
    }

    public void GetSpoilerState()
    {
        if(Input.GetKey(KeyCode.T))
            if(spoilers)
                spoilers = false;
            else
                spoilers = true;
    }

    public void UpdateGear()
    {
        if(Grounded)
        {
            //GearLeft.transform.eulerAngles = new Vector3(GearLeft.transform.eulerAngles.x, GearLeft.transform.eulerAngles.y,0);
            //GearRight.transform.eulerAngles = new Vector3(GearRight.transform.eulerAngles.x, GearRight.transform.eulerAngles.y, 0);
            GearRightNormal.SetActive(true);
            GearLeftNormal.SetActive(true);
            GearRightTilted.SetActive(false);
            GearLeftTilted.SetActive(false);
        }
        else
        {
            //GearLeft.transform.eulerAngles = new Vector3(GearLeft.transform.eulerAngles.x, GearLeft.transform.eulerAngles.y, -30);
            //GearRight.transform.eulerAngles = new Vector3(GearRight.transform.eulerAngles.x, GearRight.transform.eulerAngles.y, -30);
            GearRightNormal.SetActive(false);
            GearLeftNormal.SetActive(false);
            GearRightTilted.SetActive(true);
            GearLeftTilted.SetActive(true);
        }
    }

    public void RotateEngineProps()
    {
        EngineLeftProps.Rotate(new Vector3(0, Throttle / 40, 0));
        EngineRightProps.Rotate(new Vector3(0, Throttle / 40, 0));
    }

    public void ChanceGear()
    {
        if(Input.GetKeyDown(KeyCode.G))
        {
            if(GearUp)
            {
                GearUp = false;
                animator.SetBool("GearUp", false);
            }
            else
            {
                GearUp = true;
                animator.SetBool("GearUp", true);
            }

        }
    }

    public void HandlePushback()
    {
        if(Input.GetKeyDown(KeyCode.P))
        {
            if(pushback)
            pushback = false;
            else
            pushback = true;
        }
    }

    public void SetCursorState()
    { 
        if(!Paused && MouseControls)
        Cursor.visible = false;
        else
        Cursor.visible = true;
    }


    public void OnTriggerStay(Collider other)
    {
        Grounded = true;
    }

    public void OnTriggerExit(Collider other)
    {
        Grounded = false;
    }

}
